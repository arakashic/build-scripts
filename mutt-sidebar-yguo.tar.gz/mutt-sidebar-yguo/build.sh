# /bin/bash
#
# Prerequiste packages
sudo apt-get install libgpgme11-dev libncursesw5 libncursesw5-dev libgdbm-dev libsasl2-dev
#
rm -rf mutt-1.5.21/

wget ftp://ftp.mutt.org/mutt/devel/mutt-1.5.21.tar.gz
tar zxvf ./mutt-1.5.21.tar.gz

cd mutt-1.5.21/

patch -i ../patches/pop-cachedir.patch # FS#31536
patch -p1 -i ../patches/crypt-gpgme.patch # FS#31735

msg "Patching... Sidebar"
patch -p1 -i ../patches/patch-1.5.21.sidebar.20130219.txt

msg "Patching... Sidebar"
patch -p1 -i ../patches/sdfsidebar-corrected-by-jf.patch

msg "Patching... Trashfolder"
patch -p1 -i ../patches/trash_folder-1.5.18.patch

# msg "Patching... compressed"
# patch -p1 -i ../patches/mutt-debian/debian/patches/features/compressed-folders
# patch -p1 -i ../patches/mutt-debian/debian/patches/features/compressed-folders.debian

./configure \
        --prefix=/usr \
        --sysconfdir=/etc \
        --enable-gpgme \
        --enable-pop \
        --enable-imap \
        --enable-smtp \
        --enable-hcache \
        --with-curses=/usr/include/ncursesw \
        --with-regex \
        --with-gnutls \
        --with-idn \
        --with-sasl \
        # --enable-compressed

# make
